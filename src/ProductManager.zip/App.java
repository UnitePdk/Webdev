package ProductManager;

import ProductManager.view.ProductView;

public class App {
    public static void main(String[] args) {
        ProductView.getInstance().mainPage();
    }
}
