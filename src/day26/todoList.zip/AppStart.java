package todoList;

import todoList.view.MainView;

public class AppStart {
    public static void main(String[] args) {
        MainView.getInstance().mainPage();
    }
}
